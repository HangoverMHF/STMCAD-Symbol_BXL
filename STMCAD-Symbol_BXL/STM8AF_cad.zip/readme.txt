******************************************************************************
* @file    readme.txt
* @author  MCD Application Team
* @version V1.1
* @date    15-October-2018  
* @brief   Accelerated Designs multiple EDA CAD tools format (.bxl) files
*          for the STM8AFx MCUs.
******************************************************************************
* COPYRIGHT(c) 2017 STMicroelectronics
*
* Redistribution and use in source and binary forms, with or without modification,
* are permitted provided that the following conditions are met:
*   1. Redistributions of source code must retain the above copyright notice,
*      this list of conditions and the following disclaimer.
*   2. Redistributions in binary form must reproduce the above copyright notice,
*      this list of conditions and the following disclaimer in the documentation
*      and/or other materials provided with the distribution.
*   3. Neither the name of STMicroelectronics nor the names of its contributors
*      may be used to endorse or promote products derived from this software
*      without specific prior written permission.
*
* THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
* AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
* IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
* DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE
* FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
* DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
* SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
* CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
* OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
* OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
******************************************************************************

=======================
How to use .bxl files :
=======================

The Ultra Librarian software is a free reader from Accelerated Designs which
allows the user to view the .bxl files. It also allows the user to create symbols
and footprints for most common CAD tools. For further information, please visit
first http://www.accelerated-designs.com/.

The process to use a .bxl file is detailed below:
1. Download and install the Ultra Librarian reader.
2. Unzip the zip filed of the desired product series.
3. Open the appropriate .bxl ( the Ultra Librarian software will open automatically).
4. Export the file to the desired PCB/CAD format.

The package contains :
   + A .bxl file for each STM8AFx device or generic sub-family (x) in the different existing packages
	  o Check your device part number and select it from the list
   + A .xlsx file containing the correspondance between part number and .bxl file



==========================
* V1.1 - 15-October-2018
==========================

New release for changing names assignment for all bxl files directly corresponding to product salestypes.
No more SelectBXLFile file needed.
Here is the new list:

	STM8AF5269T
	STM8AF6288T
	STM8AF628AT
	STM8AF5268T	
	STM8AF5286U	
	STM8AF5288T
	STM8AF5289T
	STM8AF528AT
	STM8AF52A6U
	STM8AF52A8T
	STM8AF52A9T
	STM8AF52AAT
	STM8AF6213P
	STM8AF6213AP
	STM8AF6223P
	STM8AF6223AP
	STM8AF6226T
	STM8AF6226U
	STM8AF6246T
	STM8AF6246U
	STM8AF6248T
	STM8AF6266T
	STM8AF6266U
	STM8AF6268T
	STM8AF6269T
	STM8AF6286T
	STM8AF6289T
	STM8AF62A6U
	STM8AF62A8T
	STM8AF62A9T
	STM8AF62AAT
	STM8AF6366T
	STM8AF6388T
	
==========================
* V1.0 - 17-January-2017
==========================
  Created.
  

   + STM8AFx2AA_AFx28A
   + STM8AFx2x8
   + STM8AF62x6U_AFx2A6
   + STM8AFx2x9
   + STM8AF5286UC
   + STM8AF62x6T
   + STM8AF62x3
   + STM8AF6223A


  

******************* (C) COPYRIGHT 2017 STMicroelectronics *****END OF FILE
